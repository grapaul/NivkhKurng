# The standard actually prescribes the underscore and not the dash.
EMPTY_FIELD_MARKER = "-"
MORPHOSYNTACTIC_PROPERTY_SEPARATOR = '|'
