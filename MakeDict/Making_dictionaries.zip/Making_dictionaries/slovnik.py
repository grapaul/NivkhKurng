def making_a_single_dictionary(filename):

    import re
    import os
    
    CURRENT_DIR = os.getcwd()

    data = []
    with open(filename + ".txt", "r", encoding="utf8") as fin:
        for line in fin:
            line = line.strip()
            data.append(line)
    dictionary = []
    dictionary1 = []

    i = 0
    while i < len(data):
        if (data[i] != "") and ((re.split("\t| ", data[i], 1)[0][-1] in ">") and (re.split("\t| ", data[i], 1)[0][0].isdigit())):
            splitted = re.split("\t| ", data[i])
            splitted = [item for item in splitted if item]
            #print(splitted)
            matching = re.fullmatch("[А-ЯЁ]{2}:|\[[A-ZА-ЯЁ]{2}:?\]", splitted[1])
            if matching:
                del splitted[1]
            match_interrog = re.fullmatch("\((!|:|\?)\)»?", splitted[-1])
            if match_interrog:
                del splitted[-1]
            #print(splitted)
            splitted1 = re.split("\t| ", data[i+1])
            splitted1 = [item1 for item1 in splitted1 if item1]
            matching1 = re.fullmatch("[А-ЯЁ]{2}:|\[[A-ZА-ЯЁ]{2}:?\]", splitted1[1])
            if matching1:
                del splitted1[1]
            match_interrog1 = re.fullmatch("\((!|:|\?)\)»?", splitted1[-1])
            if match_interrog1:
                del splitted1[-1]
            #print(splitted1)
            #print("")
            indexes = splitted[0][:-1]
            if len(splitted[1:]) != len(splitted1[1:]):
                print(f"В ЭТОЙ СТРОКЕ ЯВНО ПРОБЛЕМА ({filename}):\n" + data[i] + "\n" + data[i+1] + "\n")
            for nivkh, rus in zip(splitted[1:], splitted1[1:]):
                dictionary.append([nivkh, rus, [indexes]])
                #print(indexes)
                #print(nivkh, rus)
                
            splitted_morph = re.split("\t|-| ", data[i])
            splitted_morph = [item for item in splitted_morph if item]
            matching2 = re.fullmatch("[А-ЯЁ]{2}:|\[[A-ZА-ЯЁ]{2}:?\]", splitted_morph[1])
            if matching2:
                del splitted_morph[1]
            match_interrog2 = re.fullmatch("\((!|:|\?)\)»?", splitted_morph[-1])
            if match_interrog2:
                del splitted_morph[-1]
            #print(splitted_morph)
            
            hyphened_words = re.search("\w+-(нибудь|то\W|либо|таки)|еле-еле|чуть-чуть|едва-едва|кое-\w+", data[i+1])   # Тут пока проблема: таких слов с дефисом может быть несколько в одной строке,
            if hyphened_words:                                                                                       # а функция re.search разбирается только с первым. Но таких случаев (когда их несколько) вообще пока не встретилось. 
                start = hyphened_words.start()
                end = hyphened_words.end()
                data[i+1] = data[i+1][:start] + hyphened_words[0].replace("-", "~") + data[i+1][end:]
            splitted_morph1 = re.split("\t|-| ", data[i+1])
            for x in range(len(splitted_morph1)):
                splitted_morph1[x] = splitted_morph1[x].replace("~", "-")
            splitted_morph1 = [item1 for item1 in splitted_morph1 if item1]
            matching3 = re.fullmatch("[А-ЯЁ]{2}:|\[[A-ZА-ЯЁ]{2}:?\]", splitted_morph1[1])
            if matching3:
                del splitted_morph1[1]
            match_interrog3 = re.fullmatch("\((!|:|\?)\)»?", splitted_morph1[-1])
            if match_interrog3:
                del splitted_morph1[-1]
            #print(splitted_morph1)
            #print("")
            if len(splitted_morph[1:]) != len(splitted_morph1[1:]):
                print(f"В ЭТОЙ СТРОКЕ ЯВНО ПРОБЛЕМА ({filename}):\n" + data[i] + "\n" + data[i+1] + "\n")
            for nivkh_morph, rus_morph in zip(splitted_morph[1:], splitted_morph1[1:]):
                dictionary1.append([nivkh_morph, rus_morph, [indexes]])
                #print(indexes)
                #print(nivkh_morph, rus_morph)
            
            i += 1
        else:
            i += 1

    # print(dictionary)

    def delete_punctuation(word):
        word = word.strip("""!,."'():«…»""")
        return word


    #dictionary = sorted(dictionary, key = lambda x: x[0])
    k = 0
    #print(dictionary)
    #print(dictionary[1][0])
    #print(type(dictionary[1][0]))
    while k < len(dictionary):
        dictionary[k][0] = delete_punctuation(dictionary[k][0])
        dictionary[k][1] = delete_punctuation(dictionary[k][1])
        k += 1

    dictionary = sorted(dictionary, key = lambda x:(x[0], x[1]))
    k = 1
    while k < len(dictionary):
        if (dictionary[k][0] == dictionary[k-1][0]) and (dictionary[k][1] == dictionary[k-1][1]):
            #print(dictionary[k-1])
            dictionary[k][2].extend(dictionary[k-1][2])
            #print(dictionary[k])
            del dictionary[k-1]
        else:
            k += 1

    #new = dict(dictionary)


    #dictionary1 = sorted(dictionary1, key = lambda x: x[0])
    m = 0
    #print(dictionary1[1][0])
    #print(type(dictionary1[1][0]))
    while m < len(dictionary1):
        dictionary1[m][0] = delete_punctuation(dictionary1[m][0])
        dictionary1[m][1] = delete_punctuation(dictionary1[m][1])
        m += 1

    dictionary1 = sorted(dictionary1, key = lambda x:(x[0], x[1]))
    m = 1
    while m < len(dictionary1):
        if (dictionary1[m][0] == dictionary1[m-1][0]) and (dictionary1[m][1] == dictionary1[m-1][1]):
            #print(dictionary1[m-1])
            dictionary1[m][2].extend(dictionary1[m-1][2])
            #print(dictionary1[m])
            del dictionary1[m-1]
        else:
            m += 1


    #new_morph = dict(dictionary1)



    with open(CURRENT_DIR + "/" + "Dictionaries/" + filename + "_dictionary.txt", "w", encoding = "utf8") as fout:
        print("Нивхско-русский словник\n\n", file=fout)
        for item in dictionary:
            print(item[0] + "\t\t" + item[1] + "\t\t" + ", ".join(item[2][::-1]), file=fout)

        print("\n\n\nСловарь морфем\n", file=fout)
        for item1 in dictionary1:
            print(item1[0] + "\t\t" + item1[1] + "\t\t" + ", ".join(item1[2][::-1]), file=fout)
    fout.close()


