import os

dictionary_directory = os.getcwd() + "/Dictionaries/"
dictionary1, dictionary2 = [], []

def reading_and_writing(file):
    with open(dictionary_directory + file, "r", encoding="utf8") as fin:
        dictionary = dictionary1
        for line in fin:
            if "Словарь морфем" in line:
                dictionary = dictionary2
            line = line.strip()
            if (line) and ("Нивхско-русский словник" not in line) and ("Словарь морфем" not in line):
                #if file == "142_lonely_young_man_dictionary.txt": print(line)
                #print(file)
                number = line.split("\t\t")[2]
                last_tabulation = line.rfind("\t\t") + 2
                dictionary.append(line[:last_tabulation] + os.path.basename(file)[:-15] + ": " + number)
    fin.close()
    

for file in os.listdir(dictionary_directory):
    reading_and_writing(file)


##a = 0
##while a < len(dictionary1):
##    first_tab = dictionary1[a].find("\t\t")
##    dictionary1[a] = dictionary1[a][:first_tab].lower() + dictionary1[a][first_tab:]
##    a += 1
##
##b = 0
##while b < len(dictionary2):
##    first_tab = dictionary2[b].find("\t\t")
##    dictionary2[b] = dictionary2[b][:first_tab].lower() + dictionary2[b][first_tab:]
##    b += 1


dictionary1.sort(key = lambda x: (x.split("\t\t")[0].lower(), x.split("\t\t")[1].lower()))
dictionary2.sort(key = lambda x: (x.split("\t\t")[0].lower(), x.split("\t\t")[1].lower()))


k = 1
while k < len(dictionary1):
    if (dictionary1[k].split("\t\t")[0] == dictionary1[k-1].split("\t\t")[0]) and (dictionary1[k].split("\t\t")[1] == dictionary1[k-1].split("\t\t")[1]):
        update = dictionary1[k-1].split("\t\t")[2]
        this_string = dictionary1[k].split("\t\t")[2]
        last_tabulation = dictionary1[k].rfind("\t\t") + 2
        dictionary1[k] = dictionary1[k][:last_tabulation] + update + ";   " + this_string
        del dictionary1[k-1]
    else:
        k += 1


m = 1
while m < len(dictionary2):
    if (dictionary2[m].split("\t\t")[0] == dictionary2[m-1].split("\t\t")[0]) and (dictionary2[m].split("\t\t")[1] == dictionary2[m-1].split("\t\t")[1]):
        update = dictionary2[m-1].split("\t\t")[2]
        this_string = dictionary2[m].split("\t\t")[2]
        last_tabulation = dictionary2[m].rfind("\t\t") + 2
        dictionary2[m] = dictionary2[m][:last_tabulation] + update + ";   " + this_string
        del dictionary2[m-1]
    else:
        m += 1



with open("Entire_dictionary.txt", "w", encoding = "utf8") as fout:
    print("Нивхско-русский словник\n\n", file=fout)
    for item in dictionary1:
        print(item, file=fout)

    print("\n\n\nСловарь морфем\n", file=fout)
    for item1 in dictionary2:
        print(item1, file=fout)
fout.close()

##print(len(dictionary1))
##print(len(dictionary2))
##print(dictionary1)
