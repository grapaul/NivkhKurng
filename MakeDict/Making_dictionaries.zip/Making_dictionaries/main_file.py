import slovnik

massive = ["a466_lvgn"]

massive1 = ["a157_bgv"]

for x in massive:
    slovnik.making_a_single_dictionary(x)
